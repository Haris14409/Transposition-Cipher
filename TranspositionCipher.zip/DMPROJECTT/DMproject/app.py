# import math
# from flask import Flask, render_template, request

# app = Flask(__name__)

# def encrypt(len_plain, len_key):
   

#     t = 0
#     for r in range(row):
#         for c, ch in enumerate(message[t : t + len_key]):
#             matrix[r][c] = ch
#         t += len_key

#     sort_order = sorted([(ch, i) for i, ch in enumerate(key)])
#     cipher_text = ''
#     for ch, c in sort_order:
#         for r in range(row):
#             cipher_text += matrix[r][c]

#     return cipher_text




#     # cipher_text = [''] * key

#     # for col in range(key):
#     #     pointer = col
#     #     while pointer < len(message):
#     #         cipher_text[col] += message[pointer]
#     #         pointer += key

#     # return ''.join(cipher_text)

# def decrypt(len_plain, len_key):

#     matrix_new = [ ['X']*len_key for i in range(row) ]
#     key_order = [ key.index(ch) for ch in sorted(list(key))]  #to make original key order when we know keyword
#     print(key_order)

#     cipher_text = ''
#     for ch,c in sort_order:
#       for r in range(row):
#         cipher_text += matrix[r][c]
    
#     t = 0
#     for c in key_order:
#       for r,ch in enumerate(cipher_text[t : t+ row]):
#         matrix_new[r][c] = ch
#       t += row
#     print(matrix_new) 

#     p_text = ''
#     for r in range(row):
#       for c in range(len_key):
#         p_text += matrix_new[r][c] if matrix_new[r][c] != 'X' else ''
#     return p_text


#     # num_of_rows = (len(cipher_text) // key) + (len(cipher_text) % key > 0)
#     # num_of_cols = key
#     # num_of_shaded_boxes = (num_of_rows * num_of_cols) - len(cipher_text)

#     # plain_text = [''] * num_of_cols
#     # col = 0
#     # row = 0

#     # for symbol in cipher_text:
#     #     plain_text[col] += symbol
#     #     col += 1
#     #     if (col == num_of_cols) or (col == num_of_cols - 1 and row >= num_of_rows - num_of_shaded_boxes):
#     #         col = 0
#     #         row += 1

#     # return ''.join(plain_text)

# @app.route('/', methods=['GET', 'POST'])
# def index():
#     result = ''
    
#     if request.method == 'POST':
#         message = request.form['message']
#         key = request.form['key']
#         action = request.form['action']

#         len_key = int(len(key))
#         len_plain = int(len(message))
#         row = int(math.ceil(len_plain / len_key))
#         matrix = [['X'] * len_key for i in range(row)]

#         if action == 'Encrypt':
#             result = encrypt(len_plain, len_key)
#         elif action == 'Decrypt':
#             result = decrypt(len_plain, len_key)

#     return render_template('index.html', result=result)

# if __name__ == '__main__':
#     app.run(debug=True)

# new logic


from flask import Flask, render_template, request

app = Flask(__name__)

def encrypt_message(key, message):
    numCols = len(key)
    numRows = len(message) // numCols + int(len(message) % numCols > 0)

    matrix = [['X'] * numCols for _ in range(numRows)]

    t = 0
    for r in range(numRows):
        for c, ch in enumerate(message[t: t + numCols]):
            matrix[r][c] = ch
        t += numCols

    cipher_text = ''
    for ch, c in sorted([(ch, i) for i, ch in enumerate(key)]):
        for r in range(numRows):
            cipher_text += matrix[r][c]

    return cipher_text

def decrypt_message(key, message):
  numCols = len(key)
  numRows = len(message) // numCols + int(len(message) % numCols > 0)

  matrix = [['X'] * numCols for _ in range(numRows)]

  key_order = [key.index(ch) for ch in sorted(list(key))]
  t = 0
  for c in key_order:
      for r, ch in enumerate(message[t: t + numRows]):
          matrix[r][c] = ch
      t += numRows

  plain_text = ''
  for r in range(numRows):
      for c in range(numCols):
          plain_text += matrix[r][c] if matrix[r][c] != 'X' else ''

  return plain_text

@app.route('/', methods=['GET', 'POST'])
def transposition_cipher():
    result = None

    if request.method == 'POST':
        message = request.form['message']
        key = request.form['key']

        action = request.form['action']

        if action == 'Encrypt':
            result = encrypt_message(key, message)
        elif action == 'Decrypt':
            result = decrypt_message(key, message)

    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
